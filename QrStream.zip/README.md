# QR Stream

Application Android (Kotlin) pour transférer des fichiers d'un téléphone à un autre **uniquement par QR codes animés**, sans réseau, Bluetooth ni câble.

## Fonctionnement

- **Émetteur** : choisit un fichier (ou « Partager → QR Stream » depuis la galerie), puis affiche un flux de QR codes à une cadence réglable de 1 à 60 images/s.
- **Récepteur** : filme l'écran. Le décodage ZXing tourne en parallèle sur plusieurs cœurs. Le fichier est vérifié (CRC32) puis enregistré dans `Téléchargements/QRStream`.
- **Code fontaine LT + élimination de Gauss** : chaque QR contient une combinaison XOR aléatoire de blocs. Le récepteur n'a pas besoin de lire tous les QR : **n'importe quels K × ~1,01 QR distincts suffisent**, quels que soient ceux qui ont été ratés (flou, reflet, désynchronisation, démarrage en retard). Il n'y a pas de voie de retour, pas d'ordre à respecter et pas de « tour » à attendre.
- Compression Deflate automatique si elle fait gagner de la place, et **recompression JPEG** des photos (optionnelle).
- **Grille 2×2** : 4 QR par image, soit un débit ×4. Le récepteur la détecte automatiquement.

## Réglages

| Réglage | Effet |
|---|---|
| Images/s (1–60) | Réglable aussi en direct pendant l'émission |
| Octets par QR (100–2900) | Plus d'octets par QR donne un QR plus dense, plus difficile à lire |
| Correction L / M / Q | L donne le débit maximal, M/Q résistent mieux aux reflets |
| 1 QR / 4 QR (2×2) | La grille demande un récepteur en 1080p et un écran émetteur assez grand |
| Recompression image | Dimension max + qualité JPEG |
| Caméra rapide 60 i/s, analyse 1080p | Côté récepteur. À désactiver si la caméra refuse de s'ouvrir |

## Débits : ce qui est réaliste

Une caméra de téléphone à 30–60 i/s ne capte pas proprement un QR différent à chaque image, et ZXing ne lit que des QR de densité raisonnable. Ordres de grandeur :

| Configuration | Débit brut | Fichier de 2 Mo |
|---|---|---|
| 20 i/s × 800 o (défaut) | 16 Ko/s | ~2 min 10 s idéal, ~3 min 30 s réel |
| 30 i/s × 1 200 o, ECC L | 36 Ko/s | ~1 min idéal, ~1 min 35 s réel |
| 20 i/s × 1 000 o × grille 2×2 | 80 Ko/s | ~25 s idéal, ~40 s réel |
| **Photo recompressée (1920 px, q80) à ~300 Ko**, 30 i/s × 1 000 o | 30 Ko/s | **~10–20 s** |

**Transférer 2 Mo bruts en quelques secondes n'est pas possible avec des QR codes standards** : il faudrait plus de 500 Ko/s, soit environ 15× la limite pratique d'un QR lu par caméra. La façon réaliste d'envoyer une *photo* de 2 Mo en quelques secondes est d'activer la recompression d'image, avec la grille 2×2 si les appareils suivent. L'écran de réglages affiche l'estimation en direct.

### Conseils de réglage

1. Commencez avec 20 i/s, 800 o, ECC L. Le récepteur doit afficher un taux « QR lus/s » proche des i/s de l'émetteur.
2. Montez le nombre d'octets par QR tant que le taux de lecture reste bon, puis montez les i/s.
3. La caméra doit tourner à au moins 1,5–2× la cadence de l'émetteur, sinon beaucoup d'images sont « à cheval » entre deux QR. Activez « Caméra rapide » si le capteur accepte 60 i/s.
4. Réglez la luminosité de l'émetteur au maximum (l'app le fait) et inclinez légèrement pour éviter les reflets. Touchez l'aperçu pour faire la mise au point.

## Compilation sur GitHub

1. Créez un dépôt GitHub et poussez-y ce dossier (le Gradle wrapper est inclus) :
   ```bash
   git init && git add . && git commit -m "QR Stream"
   git branch -M main
   git remote add origin https://github.com/<vous>/QrStream.git
   git push -u origin main
   ```
2. Ouvrez l'onglet **Actions** et le workflow « Build APK ». Il exécute les tests unitaires du codec puis compile.
3. Téléchargez l'artefact **QrStream-apk-N**. Il contient :
   - `QrStream-N.apk` : release minifiée, signée avec la clé debug si aucun keystore n'est configuré
   - `QrStream-N-debug.apk`
4. Pour publier une release : `git tag v1.0 && git push --tags`. Les APK sont alors attachés à la release GitHub.

### Signature avec votre propre clé (optionnel)

Ajoutez ces secrets au dépôt (Settings → Secrets and variables → Actions) :
`KEYSTORE_BASE64` (sortie de `base64 -w0 release.jks`), `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.

Sans ces secrets, chaque build GitHub utilise une clé debug différente. Il faut alors désinstaller l'ancienne version avant d'installer la nouvelle.

## Compilation locale

Android Studio (JDK 17), ou `./gradlew assembleDebug`.

## Format des paquets

```
[0x51][ver|grille][session:4][K:4][taille bloc:2][seq:4][longueur:4][données…][CRC32:4]
```
Le conteneur transmis contient : `"QSC1" | flags | nom | type MIME | taille | CRC32 | données (éventuellement Deflate)`.

## Structure

```
app/src/main/java/com/qrstream/
  codec/Fountain.kt     code fontaine LT (encodeur, décodeur propagation + Gauss GF(2))
  codec/Packet.kt       format binaire d'un QR
  codec/Container.kt    métadonnées + compression
  ui/MainActivity.kt    accueil + réglages + estimation
  ui/SendActivity.kt    génération et affichage des QR (Choreographer, vsync)
  ui/ReceiveActivity.kt CameraX, statistiques, sauvegarde
  ui/QrAnalyzer.kt      décodage ZXing multi-thread
app/src/test/…          tests unitaires du codec (2 Mo, 50 % de pertes)
```
