package com.qrstream.ui

import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.NotFoundException
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.Result
import com.google.zxing.ResultMetadataType
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.qrcode.QRCodeReader
import com.google.zxing.multi.qrcode.QRCodeMultiReader
import java.io.ByteArrayOutputStream
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.Semaphore
import java.util.concurrent.atomic.AtomicLong

/**
 * Analyse des images caméra : copie le plan Y (luminance) puis décode en parallèle
 * sur plusieurs cœurs avec ZXing. Les images arrivant quand tous les cœurs sont occupés
 * sont ignorées (le code fontaine rend ces pertes sans importance).
 */
class QrAnalyzer(
    private val threads: Int,
    private val onPayload: (ByteArray) -> Unit,
) : ImageAnalysis.Analyzer {

    private val pool = Executors.newFixedThreadPool(threads) { r -> Thread(r, "qr-decode").apply { priority = Thread.MAX_PRIORITY - 1 } }
    private val permits = Semaphore(threads)
    private val buffers = ArrayBlockingQueue<ByteArray>(threads + 1)

    /** true quand l'émetteur affiche une grille 2x2 (détecté automatiquement via l'en-tête). */
    @Volatile var multi = false
    @Volatile var paused = false

    private val probe = AtomicLong()
    val framesIn = AtomicLong()
    val framesDecoded = AtomicLong()
    val qrDecoded = AtomicLong()
    @Volatile var frameWidth = 0; private set
    @Volatile var frameHeight = 0; private set

    private val hints = mapOf(DecodeHintType.POSSIBLE_FORMATS to listOf(BarcodeFormat.QR_CODE))
    private val single = ThreadLocal.withInitial { QRCodeReader() }
    private val multiReader = ThreadLocal.withInitial { QRCodeMultiReader() }

    override fun analyze(image: ImageProxy) {
        try {
            framesIn.incrementAndGet()
            if (paused || !permits.tryAcquire()) return
            val w = image.width
            val h = image.height
            frameWidth = w; frameHeight = h
            val plane = image.planes[0]
            val stride = plane.rowStride
            val size = w * h
            val buf = buffers.poll()?.takeIf { it.size == size } ?: ByteArray(size)
            val src = plane.buffer
            src.rewind()
            if (stride == w && src.remaining() >= size) {
                src.get(buf, 0, size)
            } else {
                for (y in 0 until h) {
                    src.position(y * stride)
                    src.get(buf, y * w, minOf(w, src.remaining()))
                }
            }
            try {
                pool.execute {
                    try { decode(buf, w, h) } finally { buffers.offer(buf); permits.release() }
                }
            } catch (e: RejectedExecutionException) {
                permits.release()
            }
        } finally {
            image.close()
        }
    }

    private fun decode(y: ByteArray, w: Int, h: Int) {
        val source = PlanarYUVLuminanceSource(y, w, h, 0, 0, w, h, false)
        val bitmap = BinaryBitmap(HybridBinarizer(source))
        val results: Array<Result> = try {
            // une image sur 3 passe par le lecteur multi-QR pour détecter une grille 2x2
            if (multi || probe.incrementAndGet() % 3 == 0L) multiReader.get()!!.decodeMultiple(bitmap, hints)
            else arrayOf(single.get()!!.decode(bitmap, hints))
        } catch (e: NotFoundException) {
            emptyArray()
        } catch (e: Exception) {
            emptyArray() // ChecksumException / FormatException : QR flou ou à cheval sur deux images
        } finally {
            single.get()!!.reset()
        }
        if (results.isEmpty()) return
        framesDecoded.incrementAndGet()
        for (r in results) {
            val bytes = bytesOf(r) ?: continue
            qrDecoded.incrementAndGet()
            onPayload(bytes)
        }
    }

    private fun bytesOf(r: Result): ByteArray? {
        @Suppress("UNCHECKED_CAST")
        val segments = r.resultMetadata?.get(ResultMetadataType.BYTE_SEGMENTS) as? List<ByteArray>
        if (!segments.isNullOrEmpty()) {
            if (segments.size == 1) return segments[0]
            val out = ByteArrayOutputStream()
            segments.forEach { out.write(it) }
            return out.toByteArray()
        }
        return r.text?.toByteArray(Charsets.ISO_8859_1)
    }

    fun shutdown() {
        pool.shutdownNow()
    }
}
