# ZXing n'utilise pas de réflexion ; règles par défaut suffisantes.
-dontwarn com.google.zxing.**
