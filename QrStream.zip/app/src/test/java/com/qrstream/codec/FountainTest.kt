package com.qrstream.codec

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class FountainTest {

    private fun transfer(size: Int, block: Int, loss: Double, rnd: Random): Double {
        val raw = ByteArray(size).also { rnd.nextBytes(it) }
        val container = Container.pack("photo.jpg", "image/jpeg", raw)
        val enc = FountainEncoder(container, block, rnd.nextInt())
        var dec: FountainDecoder? = null
        var seq = rnd.nextInt(0, 100_000)
        var sent = 0
        while (dec?.isComplete != true) {
            val bytes = enc.packet(seq++).toBytes()
            check(++sent < enc.k * 20) { "pas de convergence" }
            if (rnd.nextDouble() < loss) continue
            val p = Packet.parse(bytes)!!
            val d = dec ?: FountainDecoder(p.sessionId, p.k, p.blockSize, p.dataLength).also { dec = it }
            d.add(p)
        }
        val out = Container.unpack(dec!!.result())
        assertArrayEquals(raw, out.data)
        assertEquals("photo.jpg", out.name)
        return dec!!.uniquePackets.toDouble() / enc.k
    }

    @Test fun smallFiles() {
        val r = Random(1)
        for (size in listOf(1, 10, 500, 5000)) transfer(size, 800, 0.3, r)
    }

    @Test fun twoMegabytesWithLosses() {
        val r = Random(2)
        for (loss in listOf(0.0, 0.5)) {
            val overhead = transfer(2_000_000, 800, loss, r)
            assertTrue("surcoût $overhead", overhead < 1.05)
        }
    }

    @Test fun corruptedPacketRejected() {
        val bytes = FountainEncoder(ByteArray(3000), 500, 7).packet(1).toBytes()
        bytes[40] = (bytes[40] + 1).toByte()
        assertNull(Packet.parse(bytes))
    }

    @Test fun compressibleData() {
        val text = "Delta Suite ".repeat(50_000).toByteArray()
        val packed = Container.pack("a.txt", "text/plain", text)
        assertTrue(packed.size < text.size / 10)
        assertArrayEquals(text, Container.unpack(packed).data)
    }
}
