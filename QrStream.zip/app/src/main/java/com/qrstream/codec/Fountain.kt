package com.qrstream.codec

import kotlin.math.ceil
import kotlin.math.ln
import kotlin.math.sqrt

/**
 * Code fontaine LT (Luby Transform) + finition par élimination de Gauss.
 *
 * Chaque paquet contient le XOR de d blocs source tirés au hasard (graine = session + seq),
 * d suivant une distribution "robust soliton".
 *
 * Intérêt : le récepteur n'a pas besoin de capter TOUS les QR codes. N'importe quel
 * ensemble d'environ K × 1,01 paquets distincts suffit, peu importe lesquels
 * ont été ratés (flou, reflet, désynchronisation écran/caméra, démarrage en retard...).
 */
class LtParams(val k: Int, val sessionId: Int) {
    private val cdf: DoubleArray = robustSolitonCdf(k)

    /** Indices des blocs source combinés dans le paquet [seq]. */
    fun indicesFor(seq: Int): IntArray {
        if (k == 1) return intArrayOf(0)
        val rng = SplitMix64(sessionId.toLong() * 0x9E3779B97F4A7C15uL.toLong() xor (seq.toLong() shl 1 or 1L))
        val u = rng.nextDouble()
        var d = cdf.binarySearchCeil(u) + 1
        if (d > k) d = k
        val out = IntArray(d)
        if (d * 2 > k) {
            // tirage partiel de Fisher-Yates
            val all = IntArray(k) { it }
            for (i in 0 until d) {
                val j = i + rng.nextInt(k - i)
                val t = all[i]; all[i] = all[j]; all[j] = t
                out[i] = all[i]
            }
        } else {
            var n = 0
            while (n < d) {
                val c = rng.nextInt(k)
                var dup = false
                for (i in 0 until n) if (out[i] == c) { dup = true; break }
                if (!dup) out[n++] = c
            }
        }
        return out
    }

    companion object {
        private fun robustSolitonCdf(k: Int, c: Double = 0.05, delta: Double = 0.1): DoubleArray {
            if (k <= 1) return doubleArrayOf(1.0)
            val r = c * ln(k / delta) * sqrt(k.toDouble())
            val pivot = ceil(k / r).toInt().coerceIn(1, k)
            val p = DoubleArray(k)
            for (d in 1..k) {
                val rho = if (d == 1) 1.0 / k else 1.0 / (d.toDouble() * (d - 1))
                val tau = when {
                    d < pivot -> r / (d.toDouble() * k)
                    d == pivot -> r * ln(r / delta) / k
                    else -> 0.0
                }
                p[d - 1] = rho + maxOf(tau, 0.0)
            }
            val sum = p.sum()
            var acc = 0.0
            return DoubleArray(k) { i -> acc += p[i] / sum; acc }.also { it[k - 1] = 1.0 }
        }

        private fun DoubleArray.binarySearchCeil(u: Double): Int {
            var lo = 0; var hi = size - 1
            while (lo < hi) {
                val mid = (lo + hi) ushr 1
                if (this[mid] < u) lo = mid + 1 else hi = mid
            }
            return lo
        }
    }
}

/** PRNG déterministe et identique sur tous les appareils. */
class SplitMix64(seed: Long) {
    private var state = seed
    fun nextLong(): Long {
        state += -0x61c8864680b583ebL
        var z = state
        z = (z xor (z ushr 30)) * -0x40a7b892e31b1a47L
        z = (z xor (z ushr 27)) * -0x6b2fb644ecceee15L
        return z xor (z ushr 31)
    }
    fun nextInt(bound: Int): Int = ((nextLong() ushr 1) % bound).toInt()
    fun nextDouble(): Double = (nextLong() ushr 11) * (1.0 / (1L shl 53))
}

class FountainEncoder(
    private val data: ByteArray,
    val blockSize: Int,
    val sessionId: Int,
    val grid: Int = 1,
) {
    val k: Int = maxOf(1, (data.size + blockSize - 1) / blockSize)
    private val params = LtParams(k, sessionId)

    private fun block(i: Int): ByteArray {
        val out = ByteArray(blockSize)
        val start = i * blockSize
        if (start < data.size) System.arraycopy(data, start, out, 0, minOf(blockSize, data.size - start))
        return out
    }

    fun packet(seq: Int): Packet {
        val idx = params.indicesFor(seq)
        val payload = block(idx[0])
        for (n in 1 until idx.size) {
            val start = idx[n] * blockSize
            val end = minOf(start + blockSize, data.size)
            for (j in start until end) payload[j - start] = (payload[j - start].toInt() xor data[j].toInt()).toByte()
        }
        return Packet(grid, sessionId, k, blockSize, seq, data.size, payload)
    }
}

/** Décodeur par propagation ("peeling"). Thread-safe. */
class FountainDecoder(val sessionId: Int, val k: Int, val blockSize: Int, val dataLength: Int) {
    private val params = LtParams(k, sessionId)
    private val blocks = arrayOfNulls<ByteArray>(k)
    private val waiting = arrayOfNulls<MutableList<Pending>>(k)
    private val seen = HashSet<Int>()
    private class Pending(val indices: MutableSet<Int>, val data: ByteArray)

    @Volatile var recovered = 0; private set
    @Volatile var uniquePackets = 0; private set
    val isComplete get() = recovered == k

    fun matches(p: Packet) = p.sessionId == sessionId && p.k == k && p.blockSize == blockSize && p.dataLength == dataLength

    /** @return true si le paquet était nouveau. */
    @Synchronized
    fun add(p: Packet): Boolean {
        if (!matches(p) || isComplete) return false
        if (!seen.add(p.seq)) return false
        uniquePackets++
        val data = p.payload.copyOf()
        val remaining = HashSet<Int>()
        for (i in params.indicesFor(p.seq)) {
            val b = blocks[i]
            if (b != null) xorInto(data, b) else remaining.add(i)
        }
        when (remaining.size) {
            0 -> {}
            1 -> recover(remaining.first(), data)
            else -> {
                val pending = Pending(remaining, data)
                for (i in remaining) (waiting[i] ?: ArrayList<Pending>(2).also { waiting[i] = it }).add(pending)
            }
        }
        if (!isComplete && uniquePackets >= k && uniquePackets - lastGaussAt >= maxOf(2, k / 200)) {
            lastGaussAt = uniquePackets
            tryGaussian()
        }
        return true
    }

    private var lastGaussAt = 0

    /**
     * Quand la propagation est bloquée, résout le reste par élimination de Gauss sur GF(2).
     * Réduit le nombre de paquets nécessaires à ~K + quelques-uns.
     */
    private fun tryGaussian() {
        val unknown = (0 until k).filter { blocks[it] == null }
        val u = unknown.size
        if (u == 0) return
        val col = HashMap<Int, Int>(u * 2).apply { unknown.forEachIndexed { c, idx -> put(idx, c) } }
        val rows = LinkedHashSet<Pending>()
        for (idx in unknown) waiting[idx]?.forEach { if (it.indices.size >= 2) rows.add(it) }
        if (rows.size < u) return
        val words = (u + 63) / 64
        val rowList = rows.toList()
        val bits = Array(rowList.size) { r ->
            LongArray(words).also { w -> for (i in rowList[r].indices) { val c = col[i]!!; w[c ushr 6] = w[c ushr 6] or (1L shl (c and 63)) } }
        }
        // 1) élimination sur les coefficients seulement, pour vérifier le rang (peu coûteux)
        val order = IntArray(rowList.size) { it }
        run {
            val m = Array(bits.size) { bits[it].copyOf() }
            for (c in 0 until u) {
                val w = c ushr 6; val bit = 1L shl (c and 63)
                var p = c
                while (p < m.size && (m[order[p]][w] and bit) == 0L) p++
                if (p == m.size) return // rang insuffisant : on attend d'autres paquets
                val t = order[c]; order[c] = order[p]; order[p] = t
                val pr = m[order[c]]
                for (r in c + 1 until m.size) {
                    val row = m[order[r]]
                    if ((row[w] and bit) != 0L) for (x in w until words) row[x] = row[x] xor pr[x]
                }
            }
        }
        // 2) rang complet : résolution de Gauss-Jordan avec les données, sur les u lignes pivots
        val mat = Array(u) { bits[order[it]] }
        val dat = Array(u) { rowList[order[it]].data.copyOf() }
        for (c in 0 until u) {
            val w = c ushr 6; val bit = 1L shl (c and 63)
            var p = c
            while ((mat[p][w] and bit) == 0L) p++
            if (p != c) { val tm = mat[p]; mat[p] = mat[c]; mat[c] = tm; val td = dat[p]; dat[p] = dat[c]; dat[c] = td }
            for (r in 0 until u) {
                if (r != c && (mat[r][w] and bit) != 0L) {
                    val a = mat[r]; val b = mat[c]
                    for (x in 0 until words) a[x] = a[x] xor b[x]
                    xorInto(dat[r], dat[c])
                }
            }
        }
        for (c in 0 until u) recover(unknown[c], dat[c])
    }

    private fun recover(index: Int, data: ByteArray) {
        val queue = ArrayDeque<Pair<Int, ByteArray>>()
        queue.add(index to data)
        while (queue.isNotEmpty()) {
            val (idx, d) = queue.removeFirst()
            if (blocks[idx] != null) continue
            blocks[idx] = d
            recovered++
            val list = waiting[idx] ?: continue
            waiting[idx] = null
            for (pend in list) {
                if (!pend.indices.remove(idx)) continue
                xorInto(pend.data, d)
                if (pend.indices.size == 1) {
                    val other = pend.indices.first()
                    pend.indices.clear()
                    if (blocks[other] == null) queue.add(other to pend.data)
                }
            }
        }
    }

    @Synchronized
    fun result(): ByteArray {
        check(isComplete)
        val out = ByteArray(dataLength)
        for (i in 0 until k) {
            val start = i * blockSize
            if (start >= dataLength) break
            System.arraycopy(blocks[i]!!, 0, out, start, minOf(blockSize, dataLength - start))
        }
        return out
    }

    private fun xorInto(dst: ByteArray, src: ByteArray) {
        for (i in dst.indices) dst[i] = (dst[i].toInt() xor src[i].toInt()).toByte()
    }
}
