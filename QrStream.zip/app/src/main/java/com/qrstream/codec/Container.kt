package com.qrstream.codec

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.util.zip.CRC32
import java.util.zip.Deflater
import java.util.zip.Inflater

/**
 * Conteneur transmis : métadonnées (nom, type MIME) + données, éventuellement compressées (Deflate).
 *
 *  "QSC1" | flags(1) | nameLen(2) name | mimeLen(1) mime | origSize(4) | crc32(orig)(4) | payload
 */
object Container {
    private val MAGIC = byteArrayOf('Q'.code.toByte(), 'S'.code.toByte(), 'C'.code.toByte(), '1'.code.toByte())
    private const val FLAG_DEFLATE = 1

    class Content(val name: String, val mime: String, val data: ByteArray)

    fun pack(name: String, mime: String, data: ByteArray, tryDeflate: Boolean = true): ByteArray {
        var flags = 0
        var payload = data
        if (tryDeflate && data.size > 256) {
            val d = deflate(data)
            // on ne garde la compression que si elle fait gagner au moins 3 %
            if (d.size < data.size * 0.97) {
                payload = d; flags = flags or FLAG_DEFLATE
            }
        }
        val nameB = name.toByteArray(Charsets.UTF_8).let { if (it.size > 1000) it.copyOf(1000) else it }
        val mimeB = mime.toByteArray(Charsets.UTF_8).let { if (it.size > 200) it.copyOf(200) else it }
        val crc = CRC32().apply { update(data) }.value.toInt()
        val buf = ByteBuffer.allocate(4 + 1 + 2 + nameB.size + 1 + mimeB.size + 4 + 4 + payload.size)
        buf.put(MAGIC).put(flags.toByte())
        buf.putShort(nameB.size.toShort()).put(nameB)
        buf.put(mimeB.size.toByte()).put(mimeB)
        buf.putInt(data.size).putInt(crc)
        buf.put(payload)
        return buf.array()
    }

    /** @throws IllegalStateException si le conteneur est corrompu. */
    fun unpack(bytes: ByteArray): Content {
        val buf = ByteBuffer.wrap(bytes)
        val magic = ByteArray(4).also { buf.get(it) }
        check(magic.contentEquals(MAGIC)) { "Conteneur invalide" }
        val flags = buf.get().toInt()
        val name = String(ByteArray(buf.short.toInt() and 0xFFFF).also { buf.get(it) }, Charsets.UTF_8)
        val mime = String(ByteArray(buf.get().toInt() and 0xFF).also { buf.get(it) }, Charsets.UTF_8)
        val origSize = buf.int
        val crc = buf.int
        val payload = ByteArray(buf.remaining()).also { buf.get(it) }
        val data = if (flags and FLAG_DEFLATE != 0) inflate(payload, origSize) else payload
        check(data.size == origSize) { "Taille incorrecte" }
        check(CRC32().apply { update(data) }.value.toInt() == crc) { "CRC incorrect" }
        return Content(name.ifBlank { "fichier.bin" }, mime.ifBlank { "application/octet-stream" }, data)
    }

    private fun deflate(data: ByteArray): ByteArray {
        val def = Deflater(Deflater.BEST_COMPRESSION)
        def.setInput(data); def.finish()
        val out = ByteArrayOutputStream(data.size / 2 + 64)
        val tmp = ByteArray(64 * 1024)
        while (!def.finished()) out.write(tmp, 0, def.deflate(tmp))
        def.end()
        return out.toByteArray()
    }

    private fun inflate(data: ByteArray, size: Int): ByteArray {
        val inf = Inflater()
        inf.setInput(data)
        val out = ByteArray(size)
        var off = 0
        while (!inf.finished() && off < size) {
            val n = inf.inflate(out, off, size - off)
            if (n == 0 && (inf.needsInput() || inf.needsDictionary())) break
            off += n
        }
        inf.end()
        check(off == size) { "Décompression incomplète" }
        return out
    }
}
