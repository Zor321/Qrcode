package com.qrstream.codec

import java.nio.ByteBuffer
import java.util.zip.CRC32

/**
 * Un paquet = le contenu binaire d'UN QR code.
 *
 * Format (big-endian) :
 *  0      1  magic 'Q' (0x51)
 *  1      1  version (4 bits hauts) | grille (4 bits bas : 1 = 1 QR/image, 4 = 2x2)
 *  2..5   4  sessionId
 *  6..9   4  K = nombre de blocs source
 *  10..11 2  taille d'un bloc (octets)
 *  12..15 4  seq (numéro de paquet, définit les blocs combinés)
 *  16..19 4  longueur totale des données (conteneur)
 *  20..   B  données (bloc ou XOR de blocs)
 *  fin    4  CRC32 de tout ce qui précède
 */
class Packet(
    val grid: Int,
    val sessionId: Int,
    val k: Int,
    val blockSize: Int,
    val seq: Int,
    val dataLength: Int,
    val payload: ByteArray,
) {
    fun toBytes(): ByteArray {
        val buf = ByteBuffer.allocate(HEADER_SIZE + payload.size + CRC_SIZE)
        buf.put(MAGIC)
        buf.put(((VERSION shl 4) or (grid and 0x0F)).toByte())
        buf.putInt(sessionId)
        buf.putInt(k)
        buf.putShort(blockSize.toShort())
        buf.putInt(seq)
        buf.putInt(dataLength)
        buf.put(payload)
        val crc = CRC32()
        crc.update(buf.array(), 0, buf.position())
        buf.putInt(crc.value.toInt())
        return buf.array()
    }

    companion object {
        const val MAGIC: Byte = 0x51
        const val VERSION = 1
        const val HEADER_SIZE = 20
        const val CRC_SIZE = 4
        const val OVERHEAD = HEADER_SIZE + CRC_SIZE

        /** Retourne null si les octets ne sont pas un paquet valide. */
        fun parse(bytes: ByteArray): Packet? {
            if (bytes.size < OVERHEAD + 1) return null
            if (bytes[0] != MAGIC) return null
            val crc = CRC32()
            crc.update(bytes, 0, bytes.size - CRC_SIZE)
            val buf = ByteBuffer.wrap(bytes)
            if (buf.getInt(bytes.size - CRC_SIZE) != crc.value.toInt()) return null
            buf.position(1)
            val vg = buf.get().toInt() and 0xFF
            if ((vg shr 4) != VERSION) return null
            val grid = vg and 0x0F
            val session = buf.int
            val k = buf.int
            val bs = buf.short.toInt() and 0xFFFF
            val seq = buf.int
            val len = buf.int
            if (k <= 0 || bs <= 0 || len < 0) return null
            if (bytes.size != OVERHEAD + bs) return null
            val payload = bytes.copyOfRange(HEADER_SIZE, HEADER_SIZE + bs)
            return Packet(grid, session, k, bs, seq, len, payload)
        }
    }
}
