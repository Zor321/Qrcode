package com.qrstream.ui

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Range
import android.util.Size
import android.view.MotionEvent
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.qrstream.codec.Container
import com.qrstream.codec.FountainDecoder
import com.qrstream.codec.Packet
import com.qrstream.databinding.ActivityReceiveBinding
import com.qrstream.databinding.DialogDoneBinding
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

class ReceiveActivity : AppCompatActivity() {
    private lateinit var b: ActivityReceiveBinding
    private lateinit var s: Settings
    private lateinit var analyzer: QrAnalyzer
    private lateinit var cameraExecutor: ExecutorService
    private val finisher = Executors.newSingleThreadExecutor()
    private var camera: Camera? = null
    private var fpsRangeLabel = "auto"

    private val sessionLock = Any()
    @Volatile private var decoder: FountainDecoder? = null
    @Volatile private var sessionStartNs = 0L
    private val completed = AtomicBoolean(false)
    private val invalidPackets = AtomicLong()

    private val ui = Handler(Looper.getMainLooper())
    private var lastFramesIn = 0L
    private var lastQr = 0L
    private var lastTickNs = 0L

    private val askCamera = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startCamera() else { Toast.makeText(this, "Permission caméra requise", Toast.LENGTH_LONG).show(); finish() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityReceiveBinding.inflate(layoutInflater)
        setContentView(b.root)
        s = Settings(this)

        cameraExecutor = Executors.newSingleThreadExecutor()
        val threads = (Runtime.getRuntime().availableProcessors() - 2).coerceIn(2, 6)
        analyzer = QrAnalyzer(threads, ::onPayload)

        b.btnReset.setOnClickListener { reset() }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else askCamera.launch(Manifest.permission.CAMERA)
    }

    // ---------------------------------------------------------------- caméra

    @SuppressLint("ClickableViewAccessibility")
    @OptIn(ExperimentalCamera2Interop::class)
    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val target = if (s.highRes) Size(1920, 1080) else Size(1280, 720)
            val resolution = ResolutionSelector.Builder()
                .setAspectRatioStrategy(AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY)
                .setResolutionStrategy(ResolutionStrategy(target, ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER))
                .build()

            val previewBuilder = Preview.Builder()
            val analysisBuilder = ImageAnalysis.Builder()
                .setResolutionSelector(resolution)
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)

            if (s.fastCamera) {
                bestFpsRange(provider)?.let { range ->
                    fpsRangeLabel = "${range.lower}-${range.upper}"
                    Camera2Interop.Extender(previewBuilder).setCaptureRequestOption(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, range)
                    Camera2Interop.Extender(analysisBuilder).setCaptureRequestOption(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, range)
                }
            }

            val preview = previewBuilder.build().also { it.setSurfaceProvider(b.preview.surfaceProvider) }
            val analysis = analysisBuilder.build().also { it.setAnalyzer(cameraExecutor, analyzer) }

            try {
                provider.unbindAll()
                val cam = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                camera = cam
                cam.cameraInfo.cameraState.observe(this) { state ->
                    state.error?.let {
                        b.txtStatus.text = "Erreur caméra (${it.code}). Essayez de désactiver « Caméra rapide » ou « 1080p »."
                    }
                }
            } catch (e: Exception) {
                b.txtStatus.text = "Impossible d'ouvrir la caméra : ${e.message}"
            }

            b.preview.setOnTouchListener { v, ev ->
                if (ev.action == MotionEvent.ACTION_UP) {
                    val point = b.preview.meteringPointFactory.createPoint(ev.x, ev.y)
                    camera?.cameraControl?.startFocusAndMetering(FocusMeteringAction.Builder(point).build())
                    v.performClick()
                }
                true
            }
            startUiTicker()
        }, ContextCompat.getMainExecutor(this))
    }

    /** Plage d'images/s la plus rapide du capteur arrière (plafond 60), plancher >= 30 de préférence. */
    @OptIn(ExperimentalCamera2Interop::class)
    private fun bestFpsRange(provider: ProcessCameraProvider): Range<Int>? = runCatching {
        val info = provider.availableCameraInfos.firstOrNull {
            Camera2CameraInfo.from(it).getCameraCharacteristic(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        } ?: return null
        val ranges = Camera2CameraInfo.from(info).getCameraCharacteristic(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
            ?: return null
        val maxUpper = ranges.filter { it.upper <= 60 }.maxOfOrNull { it.upper } ?: return null
        if (maxUpper <= 30) return null
        ranges.filter { it.upper == maxUpper }.minByOrNull { r -> if (r.lower >= 30) r.lower else 1000 - r.lower }
    }.getOrNull()

    // ---------------------------------------------------------------- réception

    private fun onPayload(bytes: ByteArray) {
        if (completed.get()) return
        val p = Packet.parse(bytes)
        if (p == null) { invalidPackets.incrementAndGet(); return }
        if ((p.dataLength.toLong() + p.blockSize - 1) / p.blockSize != p.k.toLong() || p.dataLength > MAX_SIZE) return
        analyzer.multi = p.grid == 4

        val d = synchronized(sessionLock) {
            val cur = decoder
            if (cur != null && cur.matches(p)) cur
            else FountainDecoder(p.sessionId, p.k, p.blockSize, p.dataLength).also {
                // nouvel émetteur ou émission relancée : on repart de zéro
                decoder = it
                sessionStartNs = SystemClock.elapsedRealtimeNanos()
            }
        }
        d.add(p)
        if (d.isComplete && completed.compareAndSet(false, true)) {
            analyzer.paused = true
            finisher.execute { assemble(d) }
        }
    }

    private fun assemble(d: FountainDecoder) {
        val elapsed = (SystemClock.elapsedRealtimeNanos() - sessionStartNs) / 1e9
        try {
            val content = Container.unpack(d.result())
            val saved = FileSaver.save(this, content.name, content.mime, content.data)
            runOnUiThread { showDone(content, saved, elapsed, d) }
        } catch (e: Exception) {
            runOnUiThread {
                Toast.makeText(this, "Fichier corrompu : ${e.message}", Toast.LENGTH_LONG).show()
                reset()
            }
        }
    }

    private fun showDone(content: Container.Content, saved: FileSaver.Saved, elapsed: Double, d: FountainDecoder) {
        if (isFinishing || isDestroyed) return
        val v = DialogDoneBinding.inflate(layoutInflater)
        if (content.mime.startsWith("image/")) {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(content.data, 0, content.data.size, opts)
            var sample = 1
            while (maxOf(opts.outWidth, opts.outHeight) / (sample * 2) >= 1024) sample *= 2
            BitmapFactory.decodeByteArray(content.data, 0, content.data.size, BitmapFactory.Options().apply { inSampleSize = sample })
                ?.let { v.imgPreview.setImageBitmap(it); v.imgPreview.visibility = View.VISIBLE }
        }
        v.txtDone.text = String.format(
            Locale.FRANCE, "%s\n%s en %.1f s (%s/s)\n%d paquets pour K=%d (%.3f × K)\n\nEnregistré : %s",
            content.name, MainActivity.fmtSize(content.data.size.toDouble()), elapsed,
            MainActivity.fmtSize(content.data.size / maxOf(elapsed, 0.001)),
            d.uniquePackets, d.k, d.uniquePackets.toDouble() / d.k, saved.location,
        )
        MaterialAlertDialogBuilder(this)
            .setTitle("Fichier reçu ✔")
            .setView(v.root)
            .setCancelable(false)
            .setPositiveButton("Ouvrir") { _, _ ->
                openWith(Intent(Intent.ACTION_VIEW).setDataAndType(saved.uri, content.mime))
                reset()
            }
            .setNeutralButton("Partager") { _, _ ->
                openWith(Intent.createChooser(Intent(Intent.ACTION_SEND).setType(content.mime).putExtra(Intent.EXTRA_STREAM, saved.uri)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Partager"))
                reset()
            }
            .setNegativeButton("Nouveau") { _, _ -> reset() }
            .show()
    }

    private fun openWith(intent: Intent) {
        try {
            startActivity(intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (e: Exception) {
            Toast.makeText(this, "Aucune application pour ouvrir ce fichier", Toast.LENGTH_LONG).show()
        }
    }

    private fun reset() {
        synchronized(sessionLock) { decoder = null }
        completed.set(false)
        analyzer.paused = false
        b.progressBar.setProgressCompat(0, false)
        b.txtStatus.text = "Visez l'écran de l'émetteur…"
    }

    // ---------------------------------------------------------------- statistiques

    private val ticker = object : Runnable {
        override fun run() {
            updateStats()
            ui.postDelayed(this, 250)
        }
    }

    private fun startUiTicker() {
        ui.removeCallbacks(ticker)
        lastTickNs = SystemClock.elapsedRealtimeNanos()
        ui.post(ticker)
    }

    private fun updateStats() {
        val now = SystemClock.elapsedRealtimeNanos()
        val dt = (now - lastTickNs) / 1e9
        if (dt < 0.2) return
        val fin = analyzer.framesIn.get()
        val qr = analyzer.qrDecoded.get()
        val camFps = (fin - lastFramesIn) / dt
        val qrPerSec = (qr - lastQr) / dt
        lastFramesIn = fin; lastQr = qr; lastTickNs = now

        val d = decoder
        val sb = StringBuilder()
        sb.append(String.format(Locale.FRANCE, "Caméra %dx%d · %.0f i/s (plage %s) · %d threads\n",
            analyzer.frameWidth, analyzer.frameHeight, camFps, fpsRangeLabel, (Runtime.getRuntime().availableProcessors() - 2).coerceIn(2, 6)))
        sb.append(String.format(Locale.FRANCE, "QR lus : %.1f/s · total %d · rejetés %d\n", qrPerSec, qr, invalidPackets.get()))
        if (d != null && !completed.get()) {
            val elapsed = (now - sessionStartNs) / 1e9
            val need = d.k * 1.01 + 2
            val frac = (d.uniquePackets / need).coerceAtMost(0.99)
            val rate = d.uniquePackets * d.blockSize / maxOf(elapsed, 0.001)
            val eta = maxOf(0.0, need - d.uniquePackets) * d.blockSize / maxOf(rate, 1.0)
            b.txtStatus.text = String.format(Locale.FRANCE, "Réception %s · %.0f %%", MainActivity.fmtSize(d.dataLength.toDouble()), frac * 100)
            sb.append(String.format(Locale.FRANCE, "Paquets uniques %d / ~%d · blocs décodés %d/%d\n", d.uniquePackets, need.toInt(), d.recovered, d.k))
            sb.append(String.format(Locale.FRANCE, "Débit utile %s/s · écoulé %.0f s · reste ≈ %s%s",
                MainActivity.fmtSize(rate), elapsed, MainActivity.fmtTime(eta), if (analyzer.multi) " · grille 2×2" else ""))
            b.progressBar.setProgressCompat((frac * 1000).toInt(), true)
        } else if (completed.get()) {
            b.txtStatus.text = "Reconstruction du fichier…"
            b.progressBar.setProgressCompat(1000, true)
        }
        b.txtStats.text = sb
    }

    override fun onDestroy() {
        ui.removeCallbacks(ticker)
        analyzer.shutdown()
        cameraExecutor.shutdown()
        finisher.shutdown()
        super.onDestroy()
    }

    companion object {
        private const val MAX_SIZE = 256 * 1024 * 1024
    }
}
