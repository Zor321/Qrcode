package com.qrstream.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import com.qrstream.BuildConfig
import com.qrstream.R
import com.qrstream.codec.Packet
import com.qrstream.databinding.ActivityMainBinding
import com.google.zxing.qrcode.encoder.Encoder
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private lateinit var s: Settings

    private val pickFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) startSend(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        s = Settings(this)

        b.btnSend.setOnClickListener { pickFile.launch(arrayOf("*/*")) }
        b.btnReceive.setOnClickListener { startActivity(Intent(this, ReceiveActivity::class.java)) }

        b.sliderFps.value = s.fps.toFloat()
        b.sliderBlock.value = (s.blockSize / 50 * 50).coerceIn(100, 2900).toFloat()
        b.groupEcc.check(when (s.ecc) { "M" -> R.id.eccM; "Q" -> R.id.eccQ; else -> R.id.eccL })
        b.groupGrid.check(if (s.grid == 4) R.id.grid4 else R.id.grid1)
        b.swCompress.isChecked = s.compressImages
        b.sliderDim.value = ((s.imageMaxDim - 640) / 160 * 160 + 640).coerceIn(640, 4000).toFloat()
        b.sliderQuality.value = (s.imageQuality / 5 * 5).toFloat()
        b.swCam60.isChecked = s.fastCamera
        b.swHiRes.isChecked = s.highRes

        b.sliderFps.addOnChangeListener { _, v, _ -> s.fps = v.toInt(); refresh() }
        b.sliderBlock.addOnChangeListener { _, v, _ -> s.blockSize = v.toInt(); refresh() }
        b.groupEcc.addOnButtonCheckedListener { _, id, checked ->
            if (checked) { s.ecc = when (id) { R.id.eccM -> "M"; R.id.eccQ -> "Q"; else -> "L" }; refresh() }
        }
        b.groupGrid.addOnButtonCheckedListener { _, id, checked ->
            if (checked) { s.grid = if (id == R.id.grid4) 4 else 1; refresh() }
        }
        b.swCompress.setOnCheckedChangeListener { _, c -> s.compressImages = c; refresh() }
        b.sliderDim.addOnChangeListener { _, v, _ -> s.imageMaxDim = v.toInt(); refresh() }
        b.sliderQuality.addOnChangeListener { _, v, _ -> s.imageQuality = v.toInt(); refresh() }
        b.swCam60.setOnCheckedChangeListener { _, c -> s.fastCamera = c }
        b.swHiRes.setOnCheckedChangeListener { _, c -> s.highRes = c }
        b.txtVersion.text = "v${BuildConfig.VERSION_NAME}"
        refresh()

        handleShareIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShareIntent(intent)
    }

    private fun handleShareIntent(intent: Intent?) {
        if (intent?.action != Intent.ACTION_SEND) return
        val uri: Uri? = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        else @Suppress("DEPRECATION") intent.getParcelableExtra(Intent.EXTRA_STREAM)
        intent.action = null
        if (uri != null) startSend(uri)
    }

    private fun startSend(uri: Uri) {
        startActivity(Intent(this, SendActivity::class.java).setData(uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
    }

    private fun refresh() {
        val maxBlock = QrRenderer.maxBlockFor(s.ecc)
        val block = minOf(s.blockSize, maxBlock)
        b.lblFps.text = "Vitesse : ${s.fps} images/s"
        b.lblBlock.text = "Données par QR : $block octets" + if (block < s.blockSize) " (limité par la correction ${s.ecc})" else ""
        b.boxCompress.isVisible = s.compressImages
        b.lblDim.text = "Dimension max : ${s.imageMaxDim} px"
        b.lblQuality.text = "Qualité JPEG : ${s.imageQuality}"

        val version = runCatching {
            val code = Encoder.encode(String(ByteArray(block + Packet.OVERHEAD) { 0xE9.toByte() }, Charsets.ISO_8859_1), QrRenderer.eccOf(s.ecc))
            "QR version ${code.version.versionNumber} (${code.matrix.width}×${code.matrix.width} modules)"
        }.getOrDefault("Trop de données pour un QR code")

        val bytesPerSec = s.fps * s.grid * block.toDouble()
        val total = 2_000_000 * 1.01
        val ideal = total / bytesPerSec
        val real = total / (bytesPerSec * 0.6)
        b.txtEstimate.text = buildString {
            appendLine(version + if (s.grid == 4) " ×4 par image" else "")
            appendLine("Débit brut : ${fmtSize(bytesPerSec)}/s")
            appendLine("Image de 2 Mo : ${fmtTime(ideal)} (idéal, 100 % des QR lus)")
            append("≈ ${fmtTime(real)} en conditions réelles (~60 % des QR lus)")
            if (s.compressImages) append("\nAvec recompression, une photo de 2 Mo tombe souvent à 150–400 Ko.")
        }
    }

    companion object {
        fun fmtSize(b: Double): String = when {
            b >= 1_000_000 -> String.format(Locale.FRANCE, "%.2f Mo", b / 1_000_000)
            b >= 1_000 -> String.format(Locale.FRANCE, "%.1f Ko", b / 1_000)
            else -> "${b.toInt()} o"
        }

        fun fmtTime(sec: Double): String = when {
            sec < 60 -> String.format(Locale.FRANCE, "%.0f s", sec)
            else -> String.format(Locale.FRANCE, "%d min %02d s", (sec / 60).toInt(), (sec % 60).toInt())
        }
    }
}
