package com.qrstream.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.provider.OpenableColumns
import android.view.Choreographer
import android.view.WindowManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.exifinterface.media.ExifInterface
import androidx.lifecycle.lifecycleScope
import com.qrstream.codec.Container
import com.qrstream.codec.FountainEncoder
import com.qrstream.databinding.ActivitySendBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.security.SecureRandom
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.roundToInt

class SendActivity : AppCompatActivity(), Choreographer.FrameCallback {
    private lateinit var b: ActivitySendBinding
    private lateinit var s: Settings

    private var encoder: FountainEncoder? = null
    private val frames = Channel<QrRenderer.Frame>(capacity = 8)
    private val nextSeq = AtomicInteger(0)
    private val producers = mutableListOf<Job>()

    @Volatile private var fps = 20
    private var paused = false
    private var running = false
    private var nextDueNs = 0L
    private var shownFrames = 0L
    private var shownQr = 0L
    private var lastInfoNs = 0L
    private var startNs = 0L

    private var fileLabel = ""
    private var qrLabel = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySendBinding.inflate(layoutInflater)
        setContentView(b.root)
        s = Settings(this)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.attributes = window.attributes.apply { screenBrightness = 1f }

        fps = s.fps
        b.sliderFps.value = fps.toFloat()
        b.lblFps.text = "Vitesse : $fps images/s"
        b.sliderFps.addOnChangeListener { _, v, _ ->
            fps = v.toInt(); s.fps = fps
            b.lblFps.text = "Vitesse : $fps images/s"
        }
        b.btnPause.setOnClickListener {
            paused = !paused
            b.btnPause.text = if (paused) "Reprendre" else "Pause"
        }
        b.btnStop.setOnClickListener { finish() }

        val uri = intent.data ?: run { finish(); return }
        lifecycleScope.launch {
            try {
                val ready = withContext(Dispatchers.IO) { prepare(uri) }
                encoder = ready
                b.progress.isVisible = false
                startProducers(ready)
                startNs = SystemClock.elapsedRealtimeNanos()
                startDisplay()
            } catch (e: Throwable) {
                Toast.makeText(this@SendActivity, "Erreur : ${e.message}", Toast.LENGTH_LONG).show()
                finish()
            }
        }
    }

    private fun prepare(uri: Uri): FountainEncoder {
        var name = "fichier"
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0)?.let { name = it }
        }
        var mime = contentResolver.getType(uri) ?: "application/octet-stream"
        var data = contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: error("Impossible de lire le fichier")
        val originalSize = data.size

        if (s.compressImages && mime in COMPRESSIBLE) {
            recompressImage(data, uri)?.let { jpeg ->
                if (jpeg.size < data.size) {
                    data = jpeg
                    mime = "image/jpeg"
                    name = name.substringBeforeLast('.') + ".jpg"
                }
            }
        }

        val container = Container.pack(name, mime, data)
        val block = minOf(s.blockSize, QrRenderer.maxBlockFor(s.ecc))
        val session = SecureRandom().nextInt()
        val enc = FountainEncoder(container, block, session, s.grid)

        // taille du QR pour info
        val probe = QrRenderer.render(listOf(enc.packet(0).toBytes()), QrRenderer.eccOf(s.ecc))
        fileLabel = buildString {
            append(name).append(" — ").append(MainActivity.fmtSize(originalSize.toDouble()))
            if (data.size != originalSize) append(" → ").append(MainActivity.fmtSize(data.size.toDouble())).append(" (JPEG)")
            append(" · transmis ").append(MainActivity.fmtSize(container.size.toDouble()))
        }
        qrLabel = "K=${enc.k} blocs × $block o · QR v${probe.version} ${probe.modules}×${probe.modules}" +
            (if (s.grid == 4) " · grille 2×2" else "") + " · ECC ${s.ecc}"
        return enc
    }

    private fun recompressImage(bytes: ByteArray, uri: Uri): ByteArray? = runCatching {
        val maxDim = s.imageMaxDim
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0) return null
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxDim) sample *= 2
        var bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: return null
        val big = maxOf(bmp.width, bmp.height)
        if (big > maxDim) {
            val f = maxDim.toFloat() / big
            bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * f).roundToInt(), (bmp.height * f).roundToInt(), true)
        }
        val rotation = runCatching {
            when (ExifInterface(bytes.inputStream()).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        }.getOrDefault(0f)
        if (rotation != 0f) {
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rotation) }, true)
        }
        ByteArrayOutputStream().use { out ->
            bmp.compress(Bitmap.CompressFormat.JPEG, s.imageQuality, out)
            out.toByteArray()
        }
    }.getOrNull()

    private fun startProducers(enc: FountainEncoder) {
        val ecc = QrRenderer.eccOf(s.ecc)
        val perFrame = if (enc.grid == 4) 4 else 1
        val workers = if (perFrame == 4 || s.fps > 30) 3 else 2
        repeat(workers) {
            producers += lifecycleScope.launch(Dispatchers.Default) {
                while (isActive) {
                    val payloads = List(perFrame) { enc.packet(nextSeq.getAndIncrement()).toBytes() }
                    frames.send(QrRenderer.render(payloads, ecc))
                }
            }
        }
    }

    private fun startDisplay() {
        if (running || encoder == null) return
        running = true
        nextDueNs = 0L
        Choreographer.getInstance().postFrameCallback(this)
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!running) return
        Choreographer.getInstance().postFrameCallback(this)
        val interval = 1_000_000_000L / fps.coerceAtLeast(1)
        if (!paused && frameTimeNanos + 2_000_000 >= nextDueNs) {
            val f = frames.tryReceive().getOrNull()
            if (f != null) {
                b.qrView.bitmap = f.bitmap
                shownFrames++
                shownQr += if (encoder?.grid == 4) 4 else 1
                nextDueNs = if (nextDueNs == 0L || frameTimeNanos - nextDueNs > interval) frameTimeNanos + interval
                else nextDueNs + interval
            }
        }
        if (frameTimeNanos - lastInfoNs > 400_000_000L) {
            lastInfoNs = frameTimeNanos
            val enc = encoder ?: return
            val elapsed = (SystemClock.elapsedRealtimeNanos() - startNs) / 1e9
            b.txtInfo.text = String.format(
                Locale.FRANCE, "%s\n%s\nQR affichés : %d (%.2f × K) · %.0f s · réel %.1f i/s",
                fileLabel, qrLabel, shownQr, shownQr.toDouble() / enc.k, elapsed,
                if (elapsed > 0) shownFrames / elapsed else 0.0,
            )
        }
    }

    override fun onResume() {
        super.onResume()
        startDisplay()
    }

    override fun onPause() {
        super.onPause()
        running = false
        Choreographer.getInstance().removeFrameCallback(this)
    }

    override fun onDestroy() {
        producers.forEach { it.cancel() }
        frames.close()
        super.onDestroy()
    }

    companion object {
        private val COMPRESSIBLE = setOf("image/jpeg", "image/png", "image/webp", "image/heic", "image/heif", "image/bmp")
    }
}
