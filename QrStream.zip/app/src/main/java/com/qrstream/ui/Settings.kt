package com.qrstream.ui

import android.content.Context
import androidx.core.content.edit

/** Réglages persistants (SharedPreferences). */
class Settings(context: Context) {
    private val p = context.getSharedPreferences("qrstream", Context.MODE_PRIVATE)

    /** Images QR par seconde affichées par l'émetteur. */
    var fps: Int
        get() = p.getInt("fps", 20)
        set(v) = p.edit { putInt("fps", v.coerceIn(MIN_FPS, MAX_FPS)) }

    /** Octets de données utiles par QR code. */
    var blockSize: Int
        get() = p.getInt("block", 800)
        set(v) = p.edit { putInt("block", v.coerceIn(MIN_BLOCK, MAX_BLOCK)) }

    /** Niveau de correction d'erreur QR : L, M, Q. */
    var ecc: String
        get() = p.getString("ecc", "L") ?: "L"
        set(v) = p.edit { putString("ecc", v) }

    /** 1 = un QR par image, 4 = grille 2x2 (débit x4, nécessite une bonne caméra). */
    var grid: Int
        get() = p.getInt("grid", 1)
        set(v) = p.edit { putInt("grid", if (v == 4) 4 else 1) }

    var compressImages: Boolean
        get() = p.getBoolean("imgc", false)
        set(v) = p.edit { putBoolean("imgc", v) }

    var imageMaxDim: Int
        get() = p.getInt("imgdim", 1920)
        set(v) = p.edit { putInt("imgdim", v) }

    var imageQuality: Int
        get() = p.getInt("imgq", 80)
        set(v) = p.edit { putInt("imgq", v.coerceIn(30, 100)) }

    /** Côté récepteur : demander 60 i/s à la caméra si le capteur le permet. */
    var fastCamera: Boolean
        get() = p.getBoolean("cam60", true)
        set(v) = p.edit { putBoolean("cam60", v) }

    /** Côté récepteur : analyse en 1080p (sinon 720p, plus rapide mais QR moins denses). */
    var highRes: Boolean
        get() = p.getBoolean("hires", true)
        set(v) = p.edit { putBoolean("hires", v) }

    companion object {
        const val MIN_FPS = 1
        const val MAX_FPS = 60
        const val MIN_BLOCK = 100
        const val MAX_BLOCK = 2900
    }
}
