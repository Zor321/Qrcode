package com.qrstream.ui

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.File

object FileSaver {
    class Saved(val uri: Uri, val location: String)

    fun save(ctx: Context, name: String, mime: String, data: ByteArray): Saved {
        val safeName = name.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_").take(120).ifBlank { "fichier.bin" }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = ctx.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, safeName)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/QRStream")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                resolver.openOutputStream(uri)?.use { it.write(data) } ?: error("Écriture impossible")
                resolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
                return Saved(uri, "Téléchargements/QRStream/$safeName")
            }
        }
        // Android 8/9 (ou échec MediaStore) : dossier de l'application
        val dir = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "received").apply { mkdirs() }
        var file = File(dir, safeName)
        var n = 1
        while (file.exists()) file = File(dir, safeName.substringBeforeLast('.') + " ($n)" +
            (if ('.' in safeName) "." + safeName.substringAfterLast('.') else "")).also { n++ }
        file.writeBytes(data)
        return Saved(FileProvider.getUriForFile(ctx, ctx.packageName + ".files", file), file.absolutePath)
    }
}
