package com.qrstream.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.util.AttributeSet
import android.view.View
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import com.google.zxing.qrcode.encoder.Encoder

/** Génère des bitmaps "1 pixel = 1 module" (mis à l'échelle sans lissage à l'affichage). */
object QrRenderer {
    private const val QUIET = 3

    class Frame(val bitmap: Bitmap, val version: Int, val modules: Int)

    /** Octets utiles max par QR (version 40) selon la correction d'erreur, en-tête de paquet déduit. */
    fun maxBlockFor(ecc: String) = when (ecc) {
        "M" -> 2331
        "Q" -> 1663
        else -> 2953
    } - com.qrstream.codec.Packet.OVERHEAD - 8

    fun eccOf(s: String) = when (s) {
        "M" -> ErrorCorrectionLevel.M
        "Q" -> ErrorCorrectionLevel.Q
        else -> ErrorCorrectionLevel.L
    }

    /**
     * @param payloads 1 ou 4 paquets binaires (tous de même taille => même version de QR).
     */
    fun render(payloads: List<ByteArray>, ecc: ErrorCorrectionLevel): Frame {
        // Octets bruts -> chaîne ISO-8859-1 : ZXing les encode en mode "byte" sans altération.
        val codes = payloads.map { Encoder.encode(String(it, Charsets.ISO_8859_1), ecc) }
        val m = codes[0].matrix.width
        val cell = m + 2 * QUIET
        val per = if (codes.size == 4) 2 else 1
        val side = cell * per
        val px = IntArray(side * side) { Color.WHITE }
        codes.forEachIndexed { n, code ->
            val ox = (n % per) * cell + QUIET
            val oy = (n / per) * cell + QUIET
            val mat = code.matrix
            for (y in 0 until m) {
                val row = (oy + y) * side
                for (x in 0 until m) if (mat.get(x, y).toInt() == 1) px[row + ox + x] = Color.BLACK
            }
        }
        val bmp = Bitmap.createBitmap(px, side, side, Bitmap.Config.ARGB_8888)
        return Frame(bmp, codes[0].version.versionNumber, m)
    }
}

/** Vue qui affiche un QR en plein carré, mise à l'échelle au plus proche voisin. */
class QrView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    private val paint = Paint().apply { isFilterBitmap = false; isAntiAlias = false; isDither = false }
    private val dst = Rect()
    var bitmap: Bitmap? = null
        set(v) { field = v; invalidate() }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = MeasureSpec.getSize(heightMeasureSpec)
        val s = if (h == 0) w else minOf(w, h)
        setMeasuredDimension(s, s)
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.WHITE)
        val b = bitmap ?: return
        // taille entière de module pour des bords nets
        val scale = maxOf(1, minOf(width, height) / b.width)
        val size = b.width * scale
        val l = (width - size) / 2
        val t = (height - size) / 2
        dst.set(l, t, l + size, t + size)
        canvas.drawBitmap(b, null, dst, paint)
    }
}
